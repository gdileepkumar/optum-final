import React, { Component, useState } from "react";
import logo from "./logo.svg";
import "./App.css";
import MultiChoiceQ from "./components/MultiChoiceQ";
import RangeSliderQ from "./components/RangeSliderQ";
import DateRangeQ from "./components/DateRangeQ";
import TextQ from "./components/TextQ";
import { Button, Navbar } from "react-bootstrap";
import Header from "./components/Header";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [formValues, setFormValue] = useState({
    name: '',
    food: ''
  })

  const handleChange = (e) => {
    const {name, value, type, checked} = e.target;
    //console.log({...e.target});
    setFormValue((prevFormValues) => ({
      ...prevFormValues,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  console.log('dileep', formValues)

  return (
    <div className="App">
      <Header/>
      <MultiChoiceQ formValues={formValues} handleChange={handleChange}/>
      <RangeSliderQ />
      <DateRangeQ />
      <TextQ formValues={formValues} handleChange={handleChange}/>
      <Button className='my-2' variant="success">Next</Button>{' '}
    </div>
  );
}

export default App;

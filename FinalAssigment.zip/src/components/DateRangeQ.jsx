import React, { useState } from 'react'

function DateRangeQ() {

    const [dateState,setDateState]=useState(new Date().toISOString().slice(0,10))
    const handleDate = (e) => {
        setDateState(e.target.value)
    }
    return (
        <>
            <h1>Date Range</h1>
            <input
                type='date'
                value={dateState}
                onChange={handleDate}
            />

        </>
    )
}

export default DateRangeQ

import React from 'react'
import Input from './Input'

function TextQ({handleChange,formValues}) {
    return (
        <>
            <h1>Text Question</h1>
            <Input
                label=""
                id="name"
                handleChange={handleChange}
                value={formValues.name}
            />

        </>
    )
}

export default TextQ

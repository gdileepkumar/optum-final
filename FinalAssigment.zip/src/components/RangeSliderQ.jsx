import React, { useState } from 'react'

function RangeSliderQ() {
    const [slider, setSlider] = useState({
        value: 1
    })

    const handleChange = (event) => {
        setSlider({ value: event.target.value });
    }
    return (
        <>
        <h1>Range Slider</h1>
            <input
                id="typeinp"
                type="range"
                min="0" max="5"
                value={slider.value}
                onChange={handleChange}
                step="1" />

        </>
    )
}

export default RangeSliderQ

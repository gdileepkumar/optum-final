import React from 'react'
import Radio from './Radio'

function MultiChoiceQ({handleChange, formValues}) {
    return (
        <>
            <h1>Multi choice Question</h1>
        
            <Radio
                form={formValues}
                name="food"
                label="Burger"
                id="burger"
                handleChange={handleChange}
            />
            <Radio
                form={formValues}
                name="food"
                label="Drink"
                id="drink"
                handleChange={handleChange}
            />
            

        </>
    )
}

export default MultiChoiceQ
